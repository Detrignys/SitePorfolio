const mysql = require("mysql2/promise");

const dbconfig = {
    host:"localhost",
    port:8889,
    user:"root",
    database:"ll",
    password:"root"
};
async function MysqlConnect() {
    try{
        const dbmysql = await mysql.createConnection(dbconfig);
        console.log("Подключились к БД");
        return dbmysql;
    }catch(err){
        console.error("Ошибка: ", err.message);
        throw err;
    }
}
async function MysqlEnd(dbmysql) {
    try{
        await dbmysql.end();
        console.log("Отключились от БД");
    }catch(err){
        console.error("Ошибка: ", err.message);
        throw err;
    }
}
module.exports = {MysqlConnect,MysqlEnd};
