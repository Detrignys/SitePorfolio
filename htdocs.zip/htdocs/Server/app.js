const express = require("express");
const path = require("path");
const app = express();
//подключаю нужные библиотеки
const routerOne = require("./routes/routeOne.js");

const port = 3000;
app.use(express.static(path.join(__dirname,"../Public")));//Статические страницы
app.use(express.json());//Добавил парсер json
app.use(express.urlencoded({ extended: true }));

app.set("views","./views/PersonalAccountViews");//Установка дириктории
app.set("view engine", "ejs");//движок представлений
app.use("/",routerOne);
app.use("/",function(req,res){
    res.sendFile(path.join(__dirname,"../Public","Index.html"));
});
app.use(function(req,res,next){
    res.status(404).send("Not Found")
    res.send(url);
});
app.listen(port, ()=>console.log("Сервер запущен..."));