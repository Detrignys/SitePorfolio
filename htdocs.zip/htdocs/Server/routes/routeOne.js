const express = require("express");
const ControllerOne = require("../controllers/ControllerOne.js");
const RouterOne = express.Router();

RouterOne.use("/OneProject", ControllerOne.getOneproject);//Роутер для Захода в первый проект(Главная страница входа)

RouterOne.use("/Registr", ControllerOne.getRegistation);//Роутер для регистрации в проекте

RouterOne.use("/Login", ControllerOne.getLogin);//Для входа в аккаунт 

RouterOne.use("/CreatUser",ControllerOne.CreatUser);//Роутер для создания пользователя

module.exports = RouterOne;