const model = require("../models/ModelOne");

exports.getOneproject = function(req,res){
    res.redirect("/OnePetProject/LoginAccount/LAH.html")//Заходим по статику в проект(главная страница входа)
};
exports.getRegistation = function(req,res){
    res.redirect("/OnePetProject/CreatUser/CUH.html")//Заходим на регистрацию аккаунта
};
exports.getLogin = async function(req,res){//Тут вход в аккунт (надо придумать как это будет по умному всё)
    try{
        const {login,password} = req.body;
        console.log(login,password);
        const data = await model.Authenticate(login,password);
        console.log(data);
        if(data === "incorrect login or password"){
            res.send("Неправильный логин или пароль");//Говорим что ввели что то неправильно
        }else{
            const user = data[0];
            res.render('PAH.ejs',{user});
        };
    }catch(err){
        console.error(err)
        res.status(500).send("Ошибка запроса")
    }
};
exports.CreatUser = async function(req,res){
    try{
        const {login,password,nameUser,location} = req.body;
        const data = await model.CreatPersonalData(login,password,nameUser,location);
        console.log(data);
        res.send("Пользователь создан");
    }catch(err){
        console.error(err);
        res.status(500).send("Ошибка запроса")
    }
};