const db = require("../db.js");
exports.Authenticate = async function (login,password) {
    try{
        const dbmysql = await db.MysqlConnect();
        const user = [login,password];
        const sql = "SELECT * FROM Users WHERE Login = ? AND Password = ?";
        const [result, fields] = await dbmysql.query(sql,user);
        await db.MysqlEnd(dbmysql);
        if (Array.isArray(result)){
            if(result.length === 0){
                return "incorrect login or password"
            }
            return result;
        }else{
            return "Неправильный формат данных"
        }
    }catch(err){
        console.error("Ошибка в запросе",err);
        throw err;
    }
};
exports.CreatPersonalData = async function (login,password,nameUser,location) {
    try{
        const dbmysql = await db.MysqlConnect();
        const user = [login,password,nameUser,location];
        const sql = "INSERT INTO Users (Login, Password, Name, City) VALUES (?, ?, ?, ?)";
        const [result, fields] = await dbmysql.query(sql,user);
        await db.MysqlEnd(dbmysql);
        return result;
    }catch(err){
        console.error(err);
        throw err;
    }
}